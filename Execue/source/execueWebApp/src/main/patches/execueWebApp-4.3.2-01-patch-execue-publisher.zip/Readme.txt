
Exception:
org.springframework.beans.factory.BeanCreationException: Error creating bean with name 'publisherDataEvaluationControllerService' defined in class path resource [bean-config/execue-publisher.xml]: Cannot resolve reference to bean 'execueAclService' while setting bean property 'aclService'; nested exception is org.springframework.beans.factory.NoSuchBeanDefinitionException: No bean named 'execueAclService' is defined
 at

Need to Overwrite the file execue-publisher.xml at "execueWebApp/WEB-INF/classes/bean-config/"